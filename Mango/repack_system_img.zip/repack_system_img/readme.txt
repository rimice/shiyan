./simg2img system.img system.img.raw
mkdir tmp 
sudo mount -t ext4 -o loop system.img.raw tmp/

<<change stuff, such as copy APK to tmp/app, "sudo cp test.apk tmp/app/">>

sudo ./make_ext4fs -s -l 1024M -a system system.img.new tmp/
sudo umount tmp
rm -rf tmp
